package RobustHMM;

public class BaumWelchException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public BaumWelchException(String mes){
		super(mes);
	}

}
